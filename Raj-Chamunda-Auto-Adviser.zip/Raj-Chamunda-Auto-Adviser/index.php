<HTML>
<BODY>

<script>window.location='./admin/'</script>

</BODY>
</HTML>
