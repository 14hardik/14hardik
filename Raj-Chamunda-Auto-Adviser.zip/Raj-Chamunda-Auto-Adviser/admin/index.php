<HTML>
<BODY>

<!-- <script>window.location='http://localhost/Gyanmajari%20School/gyanmajarividyapith.net/zocarro/school/account'</script> -->
<script>window.location='./account'</script>

</BODY>
</HTML>
